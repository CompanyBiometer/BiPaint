f = open('img.pit', 'w')
for i in range(1920):
    for j in range(1080):
        f.write(str('255,'))
    f.write('\n')
f.close()
